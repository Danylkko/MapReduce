import Foundation

func mapReduceSimple(words: [String], cores: Int) -> [String: Int] {
    let splitted = (0..<cores).map {
        stride(from: $0, to: words.count, by: cores).map { words[$0] }
    }
    
    let mapped = splitted.map{ $0.map { ($0, 1) }}
    
    let shuffled = Array(Dictionary(grouping: mapped.reduce([],+)){$0.0}.values)
    
    let reduced = shuffled.map{ ($0[0].0,$0.count) }
    
    var result = [String: Int]()
    
    reduced.forEach { result[$0.0] = $0.1 }
    
    return result
}

let words = ["never", "gonna", "give", "you", "up", "let", "down", "run", "around", "and", "desert"]
// by Rick Astley

func generator(source: [String], count: Int) -> [String] {
    var result = [String]()
    while result.count < count {
        result += source
    }
    while result.count > count {
        result.popLast()
    }
    return result.shuffled()
}

let source = generator(source: words, count: 1000)

print(mapReduceSimple(words: source, cores: 3))
